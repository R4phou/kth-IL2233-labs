# Folder structure
- Each file contains the code for each task

# How to run
To run each file
1. Open the notebook (on VScode with the extension or with Anaconda)
2. Select a kernel
3. Install the libraries if they are not installed yet on the selected python version
4. Click run all
